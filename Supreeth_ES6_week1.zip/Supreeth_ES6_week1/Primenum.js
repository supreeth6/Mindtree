const Primenum = Number => {
	var i = 2;
	if (Number === 1 || Number === 0) {
		return false;
	} else if (Number === 2) {
		return true;
	} else {
		while (i < Number) {
			if (Number % i === 0) {
				return false;
			}
			i++;
		}

		return true;
	}
};

console.log(Primenum(8));
