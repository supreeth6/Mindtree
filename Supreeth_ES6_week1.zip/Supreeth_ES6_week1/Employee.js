function employee() {
	var employeeid = 12;
	var jobband = "c2";
	var deptcode = 115;
	if (validjobbond(jobband) && validdeptcode(deptcode)) {
		console.log(employeeid);
	} else {
		console.log("error");
	}
}
function validjobbond(jobband) {
	if (
		jobband === "c1" ||
		jobband === "c2" ||
		jobband === "c3" ||
		jobband === "c4"
	) {
		return true;
	} else return false;
}

function validdeptcode(deptcode) {
	if (deptcode > 110 && deptcode < 125) {
		return true;
	} else return false;
}
employee();
