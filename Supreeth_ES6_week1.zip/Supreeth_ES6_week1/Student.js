let arr = [6, 7, 8, 1, 8, 1, 6, 2, 0, 3];
arr.map(element => {
	if (element > 25) {
		console.log("Give value less than 25");
	}
});

let occur = arr.reduce(
	(acc, val) => acc.set(val, 1 + (acc.get(val) || 0)),
	new Map()
);
