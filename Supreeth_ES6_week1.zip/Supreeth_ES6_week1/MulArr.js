var arr = [1, 2, 3, 4, 5, 6];
var arr2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
let concating = (arr, arr2) => {
	let i = 0;
	var l1 = arr.length;
	var l2 = arr2.length;
	if (l1 > l2) {
		for (let i in arr2) {
			arr[i] = arr[i] + arr2[i];
		}
		console.log(arr);
	} else if (l1 < l2) {
		for (let i in arr) {
			arr2[i] = arr2[i] + arr[i];
		}
		console.log(arr2);
	}
};
concating(arr, arr2);
