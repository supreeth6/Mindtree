const ReverseStrings = s => {
	return s
		.split("")
		.reverse()
		.join("");
};

console.log(ReverseStrings("Supreeth seeryada"));
