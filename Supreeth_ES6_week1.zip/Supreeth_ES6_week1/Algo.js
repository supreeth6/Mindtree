function Algo() {
	var n1 = 5;
	var n2 = 10;
	var count = 0;
	if (n1 > n2) {
		console.log("Invalid");
		System.exit(0);
	} else if (n1 <= 0 || n2 <= 0) {
		console.log("Print Invalid");
		System.exit(0);
	} else {
		while (count < 10) {
			n1 = n1 + n2;
			n2 = n2 + 10;
			console.log(+n1 + "and" + n2);
			count++;
		}
	}
}
Algo();
