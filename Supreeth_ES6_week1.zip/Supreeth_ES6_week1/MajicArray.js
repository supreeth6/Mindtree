let arr = [
	[1, 2, 3],
	[4, 5, 6],
	[7, 8, 9]
];
let sum = [];
for (let i in arr) {
	sum.push(
		arr[i].reduce((oldElement, newelement) => {
			return oldElement + newelement;
		})
	);
}
for (let i in arr) {
	let colSum = 0;
	for (let j in arr[i]) {
		colSum += arr[j][i];
	}
	sum.push(colSum);
}
let diagSum = 0;
for (let i in arr) {
	diagSum += arr[i][i];
}
sum.push(diagSum);
diagSum = 0;

for (let i in arr) {
	diagSum += arr[i][arr.length - i - 1];
}
sum.push(diagSum);

let key = sum[0],
	count = 0;
for (let element of sum) {
	if (key !== element) {
		count++;
		console.log("It is not a magic Array");
		break;
	}
}
if (count === 0) {
	console.log("It is a Magic array");
}
