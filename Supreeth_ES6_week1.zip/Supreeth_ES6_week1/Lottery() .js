function Lottery() {
	var a = 10;
	var b = 20;
	var c = 30;
	if (a != b && b != c && c != a) {
		console.log("0");
	} else if (a == b && b == c) {
		console.log("20");
	} else if (a == b || b == c || c == a) {
		console.log("10");
	}
}
Lottery();
