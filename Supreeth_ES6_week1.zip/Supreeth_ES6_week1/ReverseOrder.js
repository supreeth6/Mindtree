let Reverse = () => {
	let rev = 0;
	var num = 9876;
	let rem = 0;
	while (num > 0) {
		rem = num % 10;
		rev = rev * 10 + rem;
		num = num / 10;
		num = Math.floor(num);
	}
	console.log(rev);
};
Reverse();
