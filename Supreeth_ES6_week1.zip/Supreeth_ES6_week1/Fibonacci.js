function fibonacci() {
	var n = 7;
	console.log(evenFibonacciSum(n));
}

function evenFibonacciSum(n) {
	var result = 0;
	var a = 0;
	var b = 1;
	while (a + b < n) {
		var sum = a + b;
		a = b;
		b = sum;
		if (sum % 2 == 0) {
			result = result + sum;
		}
	}
	return result;
}
fibonacci();
