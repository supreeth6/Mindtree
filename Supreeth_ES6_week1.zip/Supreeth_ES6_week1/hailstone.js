function hailstone() {
	var n = 14;
	var count = 0;
	while (n != 1) {
		var number = n;
		if (n % 2 == 0) {
			n = n / 2;
			console.log(+number + "is even so i take half:" + n);
		} else {
			n = 3 * n + 1;
			console.log(+number + "is odd so i make 3n+1:" + n);
		}
		count++;
	}
	console.log("Thereare total" + count + "steps to reach 1");
}
hailstone();
