function Digits() {
	var a = 5;
	var count = 0;
	while (a > 0) {
		count++;
		a = a / 10;
	}
	console.log(+count);
}
Digits();
