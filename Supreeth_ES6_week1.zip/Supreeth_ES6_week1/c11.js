function fact() {
	var i, n, fact;
	fact = 1;
	n = 5;
	for (i = 1; i <= n; i++) {
		fact = fact * i;
	}
	console.log(fact);
}
