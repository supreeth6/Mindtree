var mat1 = [
	[1, 2, 3],
	[4, 5, 6],
	[7, 8, 9]
];
var mat2 = [
	[1, 2, 3],
	[4, 5, 6],
	[7, 8, 9]
];
const matrix = (mat1, mat2) => {
	var result = [];
	mat1.forEach((a1, num1) => {
		let sum = [];
		a1.forEach((num, num2) => {
			sum.push(num + mat2[num1][num2]);
		});
		result.push(sums);
	});
	return result;
};
console.log(matrix(mat1, mat2));
