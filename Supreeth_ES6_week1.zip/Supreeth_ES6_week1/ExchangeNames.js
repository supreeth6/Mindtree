const Names = () => {
	str1 = "Ahmed Al Ahmed";
	str2 = "Ali al ali";
	var s = str1.split(" ");
	var s1 = str2.split(" ");

	for (i in s) {
		for (j in s1) {
			var l = str1.replace(s[0], s1[s1.length - 1]);
			var k = str2.replace(s1[0], s[s.length - 1]);
		}
	}

	console.log(l);
	console.log(k);
};

Names();
