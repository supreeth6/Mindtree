const Initials = () => {
	var name = "supreeth s seeryada";
	var s = name;
	var x = " ";
	for (let i in name) {
		if (i == 0 || (s.charAt(i - 1) == " " && s.charAt(i) != " ")) {
			x = x + s.charAt(i);
		}
	}
	console.log(x);
};
Initials();
