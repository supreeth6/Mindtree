var arr = [1, 4, 6, 8, 5];
let result = 0;
arr.forEach(sum);
function sum(arr, index) {
	result += arr;
}
console.log(result);
