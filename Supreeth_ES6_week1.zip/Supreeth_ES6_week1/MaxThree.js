let maximum = () => {
	var a = 5;
	var b = 1;
	var c = 3;
	if (a > b && a > c) {
		console.log(a);
	} else if (b > c) {
		console.log(b);
	} else {
		console.log(c);
	}
};
maximum();
