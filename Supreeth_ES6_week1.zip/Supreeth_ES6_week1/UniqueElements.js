var arr1 = [1, 4, 5, 3, 2, 3, 4, 5, 6, 7, 87, 8];
var ans = arr1.filter((v, i, a) => a.indexOf(v) === i);

console.log(ans);
