let arr1 = [
	[3, 4, 5],
	[6, 7, 8],
	[1, 2, 3]
];
let sum = [];
for (let i in arr1) {
	sum.push(
		arr1[i].reduce((oldelement, newelement) => {
			return oldelement + newelement;
		})
	);
}

let key = sum[0],
	count = 0;
for (let newelement of sum) {
	if (key !== newelement) {
		count++;
		console.log("It is not a magic row");
		break;
	}
}
if (count === 0) {
	console.log("It is a Magic Row");
}
