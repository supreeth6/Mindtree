function Pyramid() {
	var a = 4;
	for (var i = 1; i <= a; i++) {
		for (var j = 1; j <= a - i; j++) {
			console.log(" ");
		}
		for (var k = 1; k <= i; k++) {
			console.log(+i + " ");
		}
		console.log();
	}
}
Pyramid();
