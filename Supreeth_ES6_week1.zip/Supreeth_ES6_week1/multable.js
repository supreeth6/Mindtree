function multi(number) {
	var i = 1;
	//var number = 10;
	var result = 0;
	while (i <= 10) {
		result = number * i;
		console.log(+number + "x" + i + "=" + result);
		i++;
	}
}
//multi(10);
console.log(multi(10));
