var arr = [10, 9, 14, 23, 15, 0, 9];
var lead = [];
flag = false;

for (key in arr) {
	arr.map((element, index = 1) => {
		if (arr[key] > element[index]) {
			console.log("key is present");
			return (flag = true);
		}
	});
	if (flag === true) {
		console.log("flag is present");
		lead.push(arr[key]);
	}
}
for (i in lead) {
	console.log(lead[i]);
}
