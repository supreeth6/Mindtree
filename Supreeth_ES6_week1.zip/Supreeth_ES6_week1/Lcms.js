function abc() {
	var a = 5;
	var b = 7;
	var c = lcms(a, b);
	var d = gcds(a, b, c);
	console.log("lcm" + c + "gcd" + d);
}
function lcms(a, b) {
	var large;
	if (a > b) {
		large = a;
	} else {
		large = b;
	}
	while (true) {
		if (large % a == 0 && large % b == 0) {
			return large;
		}
		large++;
	}
}
function gcds(a, b, c) {
	return (a * b) / c;
}
abc();
