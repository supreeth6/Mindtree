function compress(S) {
	var out = " ";
	var sum = 1;
	for (let i in s) {
		if (s.charAt(i) == s.charAt(i + 1)) {
			sum++;
		} else {
			out = out + s.charAt(i) + sum;
			sum = 1;
		}
	}
	out = out + s.charAt(s.length() - 1) + sum;
	//	return out.length()<s.length()?out:s;
	return out;
}
console.log(compress("supreethss"));
