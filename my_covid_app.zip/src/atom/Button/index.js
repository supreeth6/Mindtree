import React from 'react';
import Button from '@material-ui/core/Button';

function Buttonn(props) {
  return (
    <div>
      <Button
        onClick={props.handleClick}
        variant="contained"
        size="small"
        color="primary"
      >
       Click Here
      </Button>
    </div>
  );
}

export default Buttonn;
