import React from 'react'
import UserDetails from "../../pages/UserDetails"
import { Route,Switch } from 'react-router-dom'
import SearchPage from "../../pages/SearchPage";

const  Router=(props) =>{
    return (
      <Switch>
          <Route
           exact
           path="/"
           component={(props) => <SearchPage {...props} />}
         />
           <Route
           exact
           path="/singleuserListData/:items"
           component={(props) => <UserDetails {...props} />}
         />
      </Switch>
    )
}

export default Router
