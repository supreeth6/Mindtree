import React, { Component } from 'react'
import {Link,withRouter} from "react-router-dom";

import {fetchSearchUsers} from '../../store/actions';
import {AppBar,paper} from '@material-ui/core';
import Toolbar from '@material-ui/core/Toolbar';
import InputBase from '@material-ui/core/InputBase';
import SearchIcon from '@material-ui/icons/Search';
import { connect } from 'react-redux';

import  {Button, TableContainer,TableCell,TableHead,TableRow, Table, TableBody}  from '@material-ui/core'


 class SearchPage extends Component {
 constructor(props) {
     super(props);
     this.state={
         keywoord:''
     }
 }
 onHandleChange=(e)=>{
     this.setState({
         keyword:e.target.value
     })
 }
 dataChange = ()=>{
    this.props.dispatch(fetchSearchUsers(this.state.keyword));
}
render(){const {classes} = this.props
    return (
        <div >
          <AppBar position="static"style={{color:"white",backgroundColor:"skyblue"}}>
            <Toolbar>
              <div >
                <SearchIcon />
                <InputBase
                  placeholder="Search"
                  inputProps={{ 'aria-label': 'search' }}
                  onChange={this.onHandleChange}/>
                <Button  
                fullWidth
                onClick={this.dataChange}
                style={{color:"white",backgroundColor:"black"}} >Click</Button>
              </div>
              </Toolbar>
          </AppBar>
         {this.props.searchList.length<=0?(
             ""
         ):(
            <TableContainer >
            <Table style={{ minWidth: 650 }}>
              <TableHead>
                <TableRow>
                  <TableCell>Names</TableCell>
                </TableRow>
              </TableHead>
            <TableBody>
{this.props.searchList.items? (
    <>
{this.props.searchList.items.map((item)=>(
    <TableRow >
    <TableCell>
    <Link to={"/singleuserListData/"+item.login}>{item.login}</Link>
    </TableCell>
    </TableRow>
))}
    </>
         ):<>(null)</>}
        </TableBody> 
              </Table>
              </TableContainer> )} 
          </div>
      );}
  
}
function mapStateToProps(state){
    console.log(state);
    return{
        searchList: state.search,
    }
    
}
export default  withRouter(connect(mapStateToProps,null) (SearchPage))
