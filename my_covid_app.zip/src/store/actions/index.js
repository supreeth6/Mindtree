import {
    LIST_OF_USER_SUCCESS,
    LIST_OF_REPO_SUCCESS,
    LIST_OF_SEARCH_USER_SUCCESS,
    LIST_OF_FAILURE

} from "../constants/action-types"

import axios from "axios";
export function getListOfSearchUserSuccess(payload){
    return {type:LIST_OF_SEARCH_USER_SUCCESS,payload:payload}
}
export function getListOfRepoSussess(payload){
    return {type:LIST_OF_REPO_SUCCESS,payload:payload}
}
export function getListOfUSERSuccess(payload){
    return {type:LIST_OF_USER_SUCCESS,payload:payload}
}
export function getListOfFailure(){
    return {type:LIST_OF_FAILURE}
}
export const fetchSearchUsers = (keyword)=>{
    return function(dispatch){
        axios.get("https://api.github.com/search/users?q="+keyword)
        .then((response)=>{
            dispatch(getListOfSearchUserSuccess(response.data));
        }).catch((error)=>{
            dispatch(getListOfFailure());
        })
    }
}
export const fetchUsers = (url)=>{
    return function(dispatch){
        axios.get(url)
        .then((response)=>{
            dispatch(getListOfUSERSuccess(response.data));
        }).catch((error)=>{
            dispatch(getListOfFailure());
        })
    }
}
export const fetchRepo = ()=>{
    return function(dispatch){
        axios.get("https://api.github.com/repos/kentcdodds/.janus")
        .then((response)=>{
            dispatch(getListOfRepoSussess(response.data));
        }).catch((error)=>{
            dispatch(getListOfFailure());
        })
    }
}