const posts = [
	{ title: "Post one", body: "This is post one" },
	{ title: "Post Two", body: "This is post two" }
];
function getposts() {
	setTimeout(() => {
		let output = "";
		posts.forEach((post, index) => {
			output += "<li>${post.title}</li>";
		});
		document.body.innerHTML = output;
	}, 1000);
};
createPost(post) {
    setTimeout{()=>{
        posts.push(post)
    },2000);
}
getposts();
