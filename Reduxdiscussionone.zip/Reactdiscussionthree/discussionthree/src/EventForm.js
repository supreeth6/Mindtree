import React, { Component } from "react";
import { connect } from "react-redux";

class EventForm extends Component {
	handleSubmit = (e) => {
		e.preventDefault();
		const title = this.getTitle.value;
		const message = this.getMessage.value;
		const data = {
			id: new Date(),
			title,
			message,
			editing: false,
		};
		this.props.dispatch({
			type: "Add_EVENT",
			data,
		});
		this.getTitle.value = "";
		this.getMessage.value = "";
		// console.log(data);
	};
	render() {
		return (
			<div>
				<h1>Admin Dashboard</h1>
				<h2>Create Event</h2>
				<form onSubmit={this.handleSubmit}>
					<input
						required
						type="text"
						ref={(input) => (this.getTitle = input)}
						placeholder="Enter the Event Title"
					/>
					<br />
					<br />
					<textarea
						required
						rows="5"
						ref={(input) => (this.getMessage = input)}
						cols="28"
						placeholder="Enter Event description"
					/>
					<br />
					<br />
					<button>Add Event</button>
				</form>
			</div>
		);
	}
}

export default connect()(EventForm);
