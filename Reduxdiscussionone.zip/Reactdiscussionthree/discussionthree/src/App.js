import React, { Component } from "react";
import EventForm from "./EventForm";
import AllEvents from "./AllEvents";

export default class App extends Component {
	render() {
		return (
			<div>
				<EventForm />
				<AllEvents />
			</div>
		);
	}
}
