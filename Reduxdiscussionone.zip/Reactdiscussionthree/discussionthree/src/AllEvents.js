import React, { Component } from "react";
import { connect } from "react-redux";
import Event from "./Event";
import EditComponent from "./EditComponent";
// import eventReducer from "./reducers/eventReducer";

class AllEvents extends Component {
	render() {
		return (
			<div>
				<h2>All Events</h2>
				{this.props.events.map((event) => (
					<div key={event.id}>
						{event.editing ? (
							<EditComponent event={event} key={event.id} />
						) : (
							<Event key={event.id} event={event} />
						)}
					</div>
				))}
				{console.log(this.props.events)};
			</div>
		);
	}
}
const mapStateToProps = (state) => {
	return {
		events: state,
	};
};

export default connect(mapStateToProps)(AllEvents);
