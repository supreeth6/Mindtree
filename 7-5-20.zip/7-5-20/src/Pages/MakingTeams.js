import React, { Component } from "react";

import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";

import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";
import { InputLabel, MenuItem } from "@material-ui/core";
import Select from "@material-ui/core/Select";
import { makeTeams } from "../action/Actions";

class MakingTeams extends Component {
	constructor(props) {
		super(props);
		this.state = {
			detailone: {
				nameofteam: "",
				ownerofteam: "",
				addteammates: "",
				description: "",
			},
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			detailone: {
				...this.state.detailone,
				[name]: value,
			},
		});
	};
	addListone = (e) => {
		e.preventDefault();
		// console.log(e);
		let { dispatch } = this.props;
		dispatch(makeTeams("MAKE_TEAMS", this.state.detailone));
	};

	render() {
		return (
			<div>
				<form>
					<div>
						<div>
							<label>
								Name of the team
								<br />
								<TextField
									id="filled-basic"
									varient="filled-basic"
									type="text"
									name="nameofteam"
									//value={this.state.code}
									onChange={this.handleChange}
								/>
							</label>
						</div>
						<br />
						<div>
							<FormControl>
								<InputLabel>Owner of the team</InputLabel>
								<Select
									name="ownerofteam"
									value={this.state.detailone.ownerofteam}
									onChange={this.handleChange}
								>
									{this.props.teams.emp.map((a, b) => {
										console.log(a);
										return <MenuItem value={a.empname}>{a.empname}</MenuItem>;
									})}
									{/* <MenuItem value="supreeth">Supreeth</MenuItem>
									<MenuItem value="rajesh">Rajesh</MenuItem>
									<MenuItem value="suhil">Suhil</MenuItem>
									<MenuItem value="abhishek">Abhishek</MenuItem> */}
								</Select>
							</FormControl>
						</div>

						<br />

						<div>
							<FormControl>
								<InputLabel>Add Teammates</InputLabel>
								<Select
									name="addteammates"
									value={this.state.detailone.addteammates}
									onChange={this.handleChange}
								>
									{this.props.teams.emp.map((a, b) => {
										console.log(a);
										return <MenuItem value={a.empname}>{a.empname}</MenuItem>;
									})}
									{/* <MenuItem value="supreeth">Supreeth</MenuItem>
									<MenuItem value="rajesh">Rajesh</MenuItem>
									<MenuItem value="suhil">Suhil</MenuItem>
									<MenuItem value="abhishek">Abhishek</MenuItem> */}
								</Select>
							</FormControl>
						</div>
					</div>
					<br />
					<br />
					<label>
						Description
						<br />
						<TextField
							id="filled-basic"
							varient="filled-basic"
							type="text"
							name="description"
							//value={this.state.code}
							onChange={this.handleChange}
						/>
					</label>
					<br />
					<br />
					<Button
						type="button"
						variant="contained"
						color="primary"
						onClick={this.addListone}
					>
						Submit
					</Button>
				</form>
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	console.log("asdsdadsada", state);
	return {
		teams: state,
	};
};
export default connect(mapStateToProps)(MakingTeams);
