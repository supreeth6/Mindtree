import React, { Component } from "react";

import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import AppBar from "@material-ui/core/AppBar";
import AddEmployee from "../Pages/AddEmployee";

import MakingTeams from "../Pages/MakingTeams";
import ViewTeams from "../Pages/ViewTeams";

class Routersss extends Component {
	render() {
		return (
			<div>
				<AppBar position="static">Microsoft Teams</AppBar>

				<AppBar position="static" color="default">
					<Router>
						<ul>
							<li>
								<Link to="/Addemployees">Add Employee</Link>
							</li>
							<li>
								<Link to="/Makingteams">Making Teams</Link>
							</li>
							<li>
								<Link to="/viewingteams">View My Teams</Link>
							</li>
						</ul>
						<Switch>
							<Route exact path="/Addemployees" component={AddEmployee}></Route>
							<Route exact path="/Makingteams" component={MakingTeams}></Route>
							<Route exact path="/viewingteams" component={ViewTeams}></Route>
						</Switch>
					</Router>
				</AppBar>
			</div>
		);
	}
}
export default Routersss;
