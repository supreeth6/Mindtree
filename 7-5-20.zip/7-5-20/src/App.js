import React, { Component } from "react";
import Routing from "./routers/Routersss";

class App extends Component {
	render() {
		return (
			<div>
				<Routing />
			</div>
		);
	}
}
export default App;
