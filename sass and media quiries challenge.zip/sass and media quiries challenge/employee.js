const emp = [
	{
		id: 1,
		name: "Suhel",
		salary: 10000
	},
	{
		id: 2,
		name: "Rakesh",
		salary: 20000
	}
];
// for (const iterator of emp) {
// 	const convert = (emp.salary / 100) * 30;
// }
for (const salary in emp) {
	if (emp.hasOwnProperty(salary)) {
		const element = emp[salary];
	}
}

const salaryhike = emp.map(sal => {
	return sal + convert;
});
console.log(salaryhike);
