arr = [
	[1, 2, 3, 4],
	[5, 6, 7, 8],
	[9, 10, 0]
];
// for(i in arr){
//     console.log(arr[i])
// }
// arr.forEach(element => {
// 	console.log(element.arr[]);
// });
for (let i = 0; i < arr.length; i++) {
	for (let j = 0; j < arr[0].length; j++) {
		// if (i in arr) {
		if (j == 1) {
			continue;
		}
		// }
		// arr[i][1] = [];
		// delete arr[i][1];
		console.log(arr[i][j]);
		// console.log(arr[i][2]);
	}
}

// for (let i = 0; i < arr.length; i++) {
// 	for (let j = 2; j < arr[i].length; i++) {
// 		console.log(arr[i][j]);
// 		// console.log(arr[i][j + 1]);
// 	}
// }
