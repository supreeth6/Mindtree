import React, { Component } from 'react';
import { list } from '../actions/actions';
import { connect } from 'react-redux';

class List extends Component {
  componentDidMount() {
    this.props.dispatch(list());
  }
  render() {
    console.log('prodcus', this.props.state);
    return (
      <div>
        <h1>hello</h1>
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  // console.log(state);
  return { state: state.products };
};
export default connect(mapStateToProps)(List);
