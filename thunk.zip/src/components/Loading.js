import React, { Component } from 'react';
import { list } from '../actions/actions';
import { connect } from 'react-redux';

class Loading extends Component {
  clickHere = () => {
    console.log(this.props);
    this.props.dispatch(list());
  };
  render() {
    console.log(this.props.state);
    return (
      <div>
        <button onClick={this.clickHere}>click meee</button>
        <h1>{this.props.state.status}</h1>
        <h1>{this.props.state.nestedStatus}</h1>
      </div>
    );
  }
}
const mapStateToProps = (hello) => {
  console.log(hello);
  return { state: hello };
};
export default connect(mapStateToProps)(Loading);
