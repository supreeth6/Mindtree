const initialState = { products: [], status: '', nestedStatus: '' };

const reducers = (state = initialState, action) => {
  /* console.log(action);
  console.log(state); */
  switch (action.type) {
    case 'LOADING':
      return { ...state, status: action.status };

    case 'SUCCESSFUL':
      return { ...state, status: action.status, products: action.products };
    case 'FAILED':
      return { ...state, status: action.status };
    case 'NESTEDSUCCESS':
      return { ...state, nestedStatus: action.status };
    case 'NESTEDFAIL':
      return { ...state, nestedStatus: action.status };

    default:
      return state;
  }
};

export default reducers;
