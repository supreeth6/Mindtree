import axios from 'axios';

export const list = () => {
  //console.log('dr');
  return (dispatch) => {
    dispatch(loading());
    // console.log('drfrr');

    return axios
      .get('https://jsonplaceholder.typicode.com/posts')
      .then((res) => {
        // console.log('the data', res.data);
        dispatch(success(res.data));
      })
      .then((res) => {
        return axios
          .get('https://jsonplaceholder.typicode.com/posts/1/comments')
          .then((res) => {
            dispatch(nestedSucces(res.data));
          })
          .catch((error) => dispatch(nestedFail()));
      })
      .catch((error) => dispatch(failed()));
  };
};

export const success = (product) => {
  return {
    type: 'SUCCESSFUL',
    products: product,
    status: 'success',
  };
};
export const loading = () => {
  return {
    type: 'LOADING',
    status: 'loading',
  };
};
export const failed = () => {
  return {
    type: 'FAILED',
    status: 'failed',
  };
};
export const nestedSucces = (cloth) => {
  return {
    type: 'NESTEDSUCCESS',
    status: 'NESTED SUCCESS',
  };
};
export const nestedFail = () => {
  return {
    type: 'NESTEDFAIL',
    status: 'NESTED FAIL',
  };
};
