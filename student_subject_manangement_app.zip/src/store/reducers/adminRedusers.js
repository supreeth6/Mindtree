import {
    ADD_SUBJECT,
    DELETE_SUJECT,
    UPDATE_SUBJECT,
    ADD_CURRENT_UPDATE_SUBJECT,
    HANDLE_CURRENT_UPDATED_SUBJECT,
    LOGOUT,
    ADD_STUDENT,
    LOGIN,
    ADMIN,
    RESET_SUBJECT
} from '../constants/action-types';
const initialState = {
    subjects :[],
    students:[],
    listofsubjects:[],
    updatesSubjects:{}
};
export const adminStudentReducers = (state=initialState,action)=>{
    switch (action.type){
    case ADD_STUDENT :{
        return {
            ...state,
            students:[...state.students,action.payload]
        };
    }
    case "LIST_OF_SUBJECT" :
        return {
            ...state,
            listofsubjects: [...state,...action.payload]
        };

    default: return state;
    }
}

export const LoginReducer = (
    state = {email:'babitasahu567@gmail.com',password:'RK@34715874',isAdmin:false, isLogOut:false},action)=>{

        switch(action.type){
            case LOGIN:{
                return {
                    ...state,isAdmin: action.payload.email === state.email && action.payload.password ? 
                    (state.isAdmin=true):(state.isAdmin=false),
                };
            }
            case ADMIN :{
                return{
                    ...state,isAdmin:(state.isAdmin=true),
                };    
            }
            case LOGOUT:{
                return {
                    ...state,
                    isLogOut:state.isLogOut=true
                }   
            }
           
        } return state;
    }
export const adminReducers=(state = initialState, action)=>{
    switch (action.type){
        case ADD_SUBJECT:{
            return {
                ...state,
                subjects:[...state.subjects, action.payload]
            };
        
        }
        case UPDATE_SUBJECT:{
            return {
                subjects : state.subjects.map(object=>{
                    if(object.subjectId === action.payload.subjectId){
                        return action.payload;
                    }
                    return object;
                     
                })}  
        }
        case DELETE_SUJECT:{
            var Subjects = state.subjects.filter(item=>{
                if(item.subjectId!==action.payload){
                    return item;
                }
            })
            return {
                subjects:Subjects
            }

        }
        case ADD_CURRENT_UPDATE_SUBJECT:{
            return{...state,updatesSubjects:action.payload}
        }
        case HANDLE_CURRENT_UPDATED_SUBJECT:{
            return{
                ...state,
                updatesSubjects:{
                    ...state.updatesSubjects,[action.payload.target.name]: action.payload.target.value
                }
            };
        }
        case RESET_SUBJECT:{
            return {...state,
            subjects:[...initialState.subjects]}
        }
        
        default:return state;
    }
}
