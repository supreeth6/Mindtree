import {adminReducers, LoginReducer,adminStudentReducers}from '../reducers/adminRedusers';
import addAdminReducer from '../reducers/addAdminReducer';
import {combineReducers} from 'redux';
const rootReducers = combineReducers({
    subjects: adminReducers,
    login:LoginReducer,
    students:adminStudentReducers,
    allAdmins:addAdminReducer

})
export default rootReducers;
