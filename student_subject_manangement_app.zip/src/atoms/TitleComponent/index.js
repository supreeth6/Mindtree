import React from 'react';
import Typography from '@material-ui/core/Typography';
import PropTypes from 'prop-types';
function TitleComponent({ children }) {
  return (
    <Typography
      component="h2"
      variant="h5"
    >
      {children}
    </Typography>
  );
}
TitleComponent.propTypes = {
  children: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
};
export default TitleComponent;
