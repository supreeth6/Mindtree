import React from 'react';
import FormControl from '@material-ui/core/FormControl';

function FormControl({ ...props,Children }) {
  return <FormControl {...props}>{Children}</FormControl>
}

export default FormControl;
