import React from 'react';
import TableRow from '@material-ui/core/TableRow';

function TableRow({ ...rest }) {
  return <TableRow {...rest} />;
}

export default TableRow;