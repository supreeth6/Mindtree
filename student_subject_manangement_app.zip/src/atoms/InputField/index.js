import React from 'react';
import TextField from '@material-ui/core/TextField';

function InputField({ ...props }) {
  return <TextField {...props} />;
}

export default InputField;
