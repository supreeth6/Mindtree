import React from 'react';
import {addSubjects} from '../../store/actions/adminAction';
import {connect} from 'react-redux';
import * as Yup from "yup";
import {withRouter} from 'react-router-dom';
import Grid from '@material-ui/core/Grid';
import Button from '../../atoms/Button';
import InputField from '../../atoms/InputField';
import {Formik,Form,ErrorMessage} from 'formik';
import CssBaseline from '@material-ui/core/CssBaseline';
import Container from '@material-ui/core/Container';
import { makeStyles } from '@material-ui/core/styles';
import Field from '../../molecules/Form/FormFields';
import TitleComponent from '../../atoms/TitleComponent';
// import { TextField } from '@material-ui/core';
const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

 function  Subjects(props)
 {
    const classes = useStyles();
        return (  
        <Container component="main" maxWidth="xs">
         <CssBaseline />
        <div className={classes.paper}>
     <TitleComponent>Adding The Subject</TitleComponent>
        <Formik initialValues={{
       subjectName:'',
       subjectId:''
      
          }}
          validationSchema={Yup.object().shape({
            subjectName: Yup.string().required("required"),
            subjectId: Yup.number().required("required"),
           
          })}
         onSubmit={(fields)=>{
          console.log("fghjk",fields);
          props.details(fields);
          props.history.push('/dashboard')
         }}
         >
        {({values,isValid ,touched,errors,dirty})=>(
        <Form className={classes.form} >
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Field
                type="input" placeholder="subject name"   
                as={InputField} 
                label="Subject name"
                value={values.subjectName}
                variant="outlined"
                fullWidth
                autoComplete="subjectName"
                name="subjectName"
                className={"form-control"+(errors.subjectName && touched.subjectName ? "is-invalid":"")}  
              />
              <ErrorMessage name="subjectName" component="div"/>
            </Grid>
            
            <Grid item xs={12}>
              <Field
              name="subjectId"
              label="Subject"
               type="input"
               placeholder="subjectId"
               as={InputField}
                variant="outlined"
                value={values.subjectId}
                fullWidth
                className = {"form-control"+(errors.subjectId && touched.subjectId ? "is-invalid":"")}
                autoComplete="subjectId"
              />
               <ErrorMessage name="subjectId" component="div"/>
            </Grid>
          </Grid>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            disabled={!dirty || !isValid}
          >
           Add
          </Button>
        <pre>{JSON.stringify(values,null,2)}</pre>
        </Form>
         )}
        </Formik>
      </div>
    </Container>
  );
}
const mapStateToProps = state => {
	console.log(state);
    
	return {ShowSubjects: state.Subjects };
};
const mapDispatchToProps = (dispatch) => {
	return {
		details: subject => dispatch(addSubjects(subject))
	};
};
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Subjects))

