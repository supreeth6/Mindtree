import React from 'react';
import {connect} from 'react-redux';
import {addRecientUpdatedSubject} from '../store/actions/adminAction';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import { withRouter } from 'react-router';


const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
    maxWidth: 300,
  },
  chips: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  chip: {
    margin: 2,
  },
  noLabel: {
    marginTop: theme.spacing(3),
  },
}));
 function MultipleSelect(props) {
  const classes = useStyles();
  return (
    <div>
      <FormControl className={classes.formControl}>
        <InputLabel id="demo-mutiple-name-label">Subject</InputLabel>
        <Select
          labelId="demo-mutiple-name-label"
          id="demo-mutiple-name"
          multiple
        >
          {props.showList.subjects.map((item) => {
            return <option value="select">
              {item.subjectName}
            </option>
            
          })}
        </Select>
      </FormControl>
    </div>
  );
}
const mapStateToProps = state=>{
    console.log(state);
    return {showList:state.subjects}
    
}
const mapDispatchToProps =dispatch=>{
    return{
    sendRecientUpdatedSubject: subject => dispatch(addRecientUpdatedSubject(subject))

    }
}
export default withRouter(connect(mapStateToProps,mapDispatchToProps)(MultipleSelect));