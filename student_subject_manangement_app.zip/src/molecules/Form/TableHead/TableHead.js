import React from 'react';
import PropTypes from 'prop-types';

import React from 'react'

function TableHead() {
    return (
        <div>
             return <TableHead {...rest} />;
        </div>
    )
}

export default TableHead
