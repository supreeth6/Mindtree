import React from 'react';
import {logout,login,resetSubjects} from "../../store/actions/adminAction";
import { Link,withRouter } from 'react-router-dom';
import {connect} from "react-redux"
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import  Button  from '../../atoms/Button/index';
import { TablePagination } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    justifyContent: 'space-around',
    backgroundColor:'black',
    textDecorationColor:'white'
  
   
  },
  
  menuButton: {
    marginRight: theme.spacing(2),
   
  },
  title: {
    flexGrow: 1,
  },
}));

function Header(props) {
const classes = useStyles();
  const isLogOut=(data)=>{
    console.log(props);
    props.dispatch(logout());
    props.dispatch(resetSubjects())    
  }
  return (
    <div style={{height:'990px'}}>
    <div className={classes.root} >
      <AppBar position="static" >
        <Toolbar className={classes.root}>
          <IconButton edge="start" className={classes.menuButton} color="inherit" aria-label="menu">
           LOGO
          </IconButton>
          <Typography variant="h6"style={{color:'white'}} className={classes.title}>
       details
          </Typography>
            
          {/* <Typography className={classes.root} > <Link to="/dashboard">Dashboard</Link></Typography> */}
        <Typography className={classes.root}><Link style={{textDecorationLine:'none',color:'white'}} to='/home'>Home</Link><br/></Typography>
        {/* <Typography className={classes.root}><Link to='/'></Link><br/></Typography> */}
        <Typography className={classes.root}><Link style={{textDecorationLine:'none',color:'white'}} to='/newlistofsubject'>List Subject</Link><br/></Typography>

      <Typography className={classes.root} > <Link style={{textDecorationLine:'none',color:'white'}} to="/login">Login</Link></Typography>
      <Button type="onClick"
            // fullWidth
            onClick={isLogOut}
            className={classes.roots}
            variant="contained"
            color="primary"
            style={{ textDecorationLine:"none"}}
            >Logout</Button>

        </Toolbar>
      </AppBar>
    </div>
    </div>
  );
}
const mapStateToProps = state =>{
 
  return {showList: state.subjects,
  login:state.login,
}
}
// const mapDispatchToProps = dispatch =>{
//   logOut: dispatch(logout());
//   reset: dispatch(resetSubjects())
// }

export default withRouter(connect(mapStateToProps)(Header));