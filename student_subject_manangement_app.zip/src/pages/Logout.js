import React from 'react';
import {
    Route
  
} from 'react-router';
import {
    LogoutView
} from '../pages';
import Login from '../organism/Login/Login';
import Header from '../pages/Home/';

export default <Route path='/'>
    <Route component={Header} />
    <Route path='/logout'component={LogoutView} />
    <Route path='/login' component={Login} />
</Route>;