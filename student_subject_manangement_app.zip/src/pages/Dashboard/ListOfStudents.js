import React from 'react';
import {withRouter} from "react-router-dom";
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import {connect} from 'react-redux';
const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
});
function ListOfStudents(props) {
  const classes = useStyles();

  return (
    <TableContainer component={Paper}>
      <Table className={classes.table} size="small" aria-label="a dense table">
        <TableHead>
        <h1 align="center">All Students Detail</h1>
        <br/>
        <br/>
          <TableRow>
            <TableCell align="left">Student Name</TableCell>
            <TableCell align="left">Email</TableCell>
            <TableCell align="left">Number</TableCell>
            <TableCell align="left">Roll-Number</TableCell>
            <TableCell align="left">Passwords</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {props.showList.students.map((item) => (
            <TableRow key={item.subjectId}>
              <TableCell align="left">{item.studentName}</TableCell>
              <TableCell align="left">{item.email}</TableCell>
              <TableCell align="left">{item.number}</TableCell>
              <TableCell align="left">{item.rollNumber}</TableCell> 
              <TableCell align="left">{item.password}</TableCell>              
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
const mapStateToProps = state => {
	console.log(state);
    
	return {showList: state.students };
};

export default withRouter(connect(mapStateToProps,null)(ListOfStudents));