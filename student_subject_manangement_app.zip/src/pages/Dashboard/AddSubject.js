import React from 'react';
import Subjects from '../../organism/Subjects';

function AddSubject() {
  return (   
    <div>
   <Subjects/>
   </div>
  );
}

export default AddSubject;
