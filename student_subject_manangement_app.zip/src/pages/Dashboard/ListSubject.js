import React from 'react';
import {withRouter} from "react-router-dom";
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import {connect} from 'react-redux';
import {deleteSubject,addRecientUpdatedSubject} from "../../store/actions/adminAction";
import { Button } from '@material-ui/core';

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
});
function ListSubject(props) {
  const classes = useStyles();

  return (
    <TableContainer component={Paper}>
      <Table className={classes.table} size="small" aria-label="a dense table">
        <TableHead>
        <TableCell align="center">All Subjects</TableCell>
        <br/>
        <br/>
          <TableRow>
            <TableCell align="left">Name</TableCell>
            <TableCell align="left">Id</TableCell>
            <TableCell >Delete</TableCell>
            <TableCell>Update</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {props.showList.subjects.map((item) => (
            <TableRow key={item.subjectId}>
                 <TableCell align="center">Subjects</TableCell>
              <TableCell align="right">{item.subjectName}</TableCell>
              <TableCell align="right">{item.subjectId}</TableCell>
              <TableCell align="right">
              <Button 
              type="onClick"
               fullWidth
               variant="contained"
               color="primary"
               className={classes.onClick}
               onClick={() => {props.sendRecientUpdatedSubject(item);
                props.history.push("/updatesubject");
                  }}>
                  Update
                </Button>
                </TableCell>
                <TableCell align="right">
                <Button 
                type="onClick"
                fullWidth
                variant="contained"
                color="primary"
                className={classes.onClick} 
                onClick={()=> {props.delete(item.subjectId)}}>
                  Delete
                </Button>
                </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
const mapStateToProps = state => {
	console.log(state);
    
	return {showList: state.subjects };
};
const mapDispatchToProps = dispatch => { 
		return {
		delete: del => dispatch(deleteSubject(del)),
		sendRecientUpdatedSubject: subject => dispatch(addRecientUpdatedSubject(subject))
	};
};
export default withRouter(connect(mapStateToProps, mapDispatchToProps,null)(ListSubject));