import React from "react";

import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
import Tab from "@material-ui/core/Tab";
import Box from "@material-ui/core/Box";
import Tabs from "@material-ui/core/Tabs";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";

import { Link, withRouter } from "react-router-dom";

const Menu = () => (
	<div>
		<AppBar position="static">
			<Tabs>
				<nav>
					<Link to="/">Home</Link> |<Link to="/signin">signin</Link> |
					<Link to="/signup">signup</Link> |
					{/* <Button color="inherit">Login</Button> */}
				</nav>
			</Tabs>
		</AppBar>
		{/* <ul>
			<li>
				<Link to="/">Home</Link>
			</li>
			<li>
				<Link to="/signin">signin</Link>
			</li>
			<li>
				<Link to="/signup">signup</Link>
			</li>
		</ul> */}
	</div>
);
export default withRouter(Menu);
