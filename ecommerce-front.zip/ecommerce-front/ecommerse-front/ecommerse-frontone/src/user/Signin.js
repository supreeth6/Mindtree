import React, { useState } from "react";
import Layout from "../core/Layout";

import { Redirect } from "react-router-dom";
import { signin } from "../auth";

const Signin = () => {
	const [values, setValues] = useState({
		email: "",
		password: "",
		error: "",
		loading: false,
		redirectToReferrer: false,
	});

	const { email, password, error, loading, redirectToReferrer } = values;

	const handleChange = (name) => (event) => {
		setValues({ ...values, error: false, [name]: event.target.value });
	};

	const clickSubmit = (event) => {
		event.preventDefault();
		setValues({ ...values, error: false, loading: true });
		signin({ email, password }).then((data) => {
			if (data.error) {
				setValues({ ...values, error: data.error, loading: false });
			} else {
				setValues({
					...values,

					redirectToReferrer: true,
				});
			}
		});
	};

	const signUpForm = () => (
		<form>
			<div>
				<label>Email</label>
				<input onChange={handleChange("email")} type="email" value={email} />
			</div>
			<div>
				<label>Password</label>
				<input
					onChange={handleChange("password")}
					type="password"
					value={password}
				/>
			</div>
			<button onClick={clickSubmit}>Submit</button>
		</form>
	);

	const showError = () => (
		<div style={{ display: error ? " " : "none" }}>{error}</div>
	);
	const showLoading = () =>
		loading && (
			<div>
				<h2>loading...</h2>
			</div>
		);
	const redirectUser = () => {
		if (redirectToReferrer) {
			return <Redirect to="/" />;
		}
	};

	return (
		<Layout title="Signup" description="Signup to mobile React E-commerce App">
			{showLoading()}
			{showError()}
			{signUpForm()}
			{redirectUser()}
		</Layout>
	);
};

export default Signin;
