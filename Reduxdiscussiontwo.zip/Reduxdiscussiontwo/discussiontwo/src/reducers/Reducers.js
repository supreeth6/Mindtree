const initialState = {
	hospital: [],
	doctorsss: [],
};
const Reducer = (state = initialState, action) => {
	// console.log("to update", state, action);

	switch (action.type) {
		case "ADD_ADMINS":
			const { admins } = action;
			return {
				...state,
				hospital: [...state.hospital, admins],
			};
			break;
		case "ADD_USAGE":
			const { usage } = action;
			return {
				...state,
				doctorsss: [...state.hospital, usage],
			};
			break;
		default:
			return state;
	}
};

export default Reducer;
