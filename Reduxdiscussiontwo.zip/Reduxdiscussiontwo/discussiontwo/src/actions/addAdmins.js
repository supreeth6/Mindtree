export const adding = (actionType, admins) => {
	console.log(admins);
	return {
		type: actionType,
		admins: admins,
	};
};
export const addingone = (actionType, admins) => {
	console.log(admins);
	return {
		type: actionType,
		admins: admins,
	};
};
