import React, { Component } from 'react'

export default class Update extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}
