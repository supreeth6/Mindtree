import React, { Component } from "react";
class List1 extends Component {
	render() {
		return (
			<div>
				<tr>
					<td>dresscode</td>
					<td>gender</td>
					<td>skills</td>
				</tr>
				{this.props.data.map((Element, i) => {
					return (
						<tr>
							<td>{Element.dresscode}</td>
							<td>{Element.gender}</td>
							<td>{Element.skills}</td>
							<td>
								<button onClick={e => this.props.remove(i)}>delete</button>
							</td>
						</tr>
					);
				})}
			</div>
		);
	}
}
export default List1;
