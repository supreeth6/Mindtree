import React, { Component } from "react";
import Form1 from "./components1.js/Form1";
import List1 from "./components1.js/List1";

class App1 extends Component {
	constructor(props) {
		super(props);
		this.state = {
			clothes: [],
			cloth: "",
			index: ""
		};
	}
	changer = cloth => {
		const { clothes } = this.state;
		this.setState({ clothes: [...clothes, cloth] });
	};

	deletedata = index => {
		const { clothes } = this.state;
		this.setState({ clothes: clothes.filter((Element, i) => index !== i) });
	};
	updatadata = (Element, index) => {
		this.setState({
			cloth: Element,
			index: index
		});
	};
	render() {
		return (
			<div>
				<Form1 clicker={this.changer} />
				<List1 data={this.state.clothes} remove={this.deletedata} />
			</div>
		);
	}
}
export default App1;
