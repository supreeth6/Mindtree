// import React, { Component } from "react";

// export class List extends Component {
// 	render() {
// 		console.log(this.props);

// 		return (
// 			<div>
// 				<tr>
// 					<td>Code</td>
// 					<td>Gender</td>
// 					<td>Type</td>
// 				</tr>
// 				{this.props.data.map((Element, i) => {
// 					return (
// 						<tr key={i}>
// 							<td>{Element.code}</td>
// 							<td>{Element.gender}</td>
// 							<td>{Element.type}</td>
// 							<td>
// 								<button type="button">Update</button>
// 							</td>
// 							<td>
// 								<button type="button" onClick={e => this.props.remove(i, e)}>
// 									DELETE
// 								</button>
// 							</td>
// 						</tr>
// 					);
// 				})}
// 			</div>
// 		);
// 	}
// }

// export default List;
