import React, { Component } from 'react'
import {addoption} from "../store/action/action"
export default class Radio extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             inputs:['input-0'],
             option:""
        }
    }
    
    handleChange=(e)=>{
        this.setState({
            [e.target.name]:e.target.value
        })
    }
    handlesubmit=()=>{
        this.props.dispatch(addoption(this.state));
        this.props.history.push("/");
    }
    render() {
        return (
            <div>
                  <form>
                     <div >
                         {this.state.inputs.map((input)=>{
                             return(
                                 <>
                                <input type="radio" name="same" key={input} />
                               
                                <input type="text" name="option" onChange={this.handleChange} />
                                <br/>
                                </>
                             )
                            
                         })}
                     </div>
                 </form>
                 <button onClick={()=>this.appendInput()}>Add option</button>
                 <button onClick={this.handlesubmit}>submit</button>
            </div>
        )
    }
    appendInput(){
        var newInput=`input-$(this.state.inputs.length)`;
        this.setState((prevState)=>({
            inputs:prevState.inputs.concat([newInput]),
        }))
    }
}
