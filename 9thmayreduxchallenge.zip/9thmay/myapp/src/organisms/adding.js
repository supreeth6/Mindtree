import React, { Component } from 'react'
import {connect} from "react-redux";
import {withRouter,Link} from "react-router-dom";
import {addaction} from "../store/action/action";
 class Adding extends Component {
    constructor(props){
        super(props);
        this.state={
            details:{
        question:"",
        option:[],
        radiobutton:false,
       
          
            }
        }
    }
   const handleAddoption=(e)=>{
       
   }
      handlechange=(event)=>{
       // let name=event.target.name
        let value=event.target.value;
        this.setState(prevState=>({
            details:{
                ...prevState.details,
                option:[...this.state.details.option,value]
            }
         }))
        }
        handlesubmit=()=>{
            this.props.dispatch(addaction(this.state.details));
             this.props.history.push("/");
         }
         handler=(event)=>{
            let value=event.target.value;
            this.setState(prevState=>({
                details:{
                    ...prevState.details,
                    question:value
                }
             }))
            
         }
          
        //  handleradio=()=>{
        //     this.setState({
        //         details:{
        //             ...prevState.details,
        //                  radiobutton:true,
        //                 option:[...this.state.details.value]
        //         }
        //     }) 
        //  }
    render() {

        return (
           
            <div>
                 {/* <form>
                     <div >
                         {this.state.inputs.map((input)=>{
                             return(
                                <input type="radio" name="same" key={input} />
                             )
                            
                         })}
                     </div>
                 </form> */}
                 <input type="text" placeholder="question" name="question" onChange={this.handlechange}/>
                <br/>
                <Link to="/addoption">
                <button onClick={this.handleradio}>add option</button>
               <br/>
               </Link>
            
             {
               !this.state.details.radiobutton?
               "":
               (
                   <>
                <label>{this.state.details.option} </label>      
                <input type="radio"  />
                </>
               )
               }
                <button onClick={this.handlesubmit}>submit</button>
              
            </div>
            
        )
    }
    appendInput(){
        var newInput=`input-$(this.state.inputs.length)`;
        this.setState((prevState)=>({
            inputs:prevState.inputs.concat([newInput]),
        }))
    }
}
export default withRouter (connect()(Adding));
