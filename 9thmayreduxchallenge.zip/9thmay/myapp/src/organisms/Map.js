import React, { Component } from 'react'
import {connect} from "react-redux";
export default class Map extends Component {
    render() {
        return (
            <div>
                {this.props.state.map(element=>{
                    return(
                        <>
                        <p>{element.question}</p>
                        {this.props.state.map((element,i)=>{
                            return(
                                <ol>
                                <li> {element.option[i]}</li>

                                </ol>

                            )
                        })}
                      
                        </>
                    )
                })}
            </div>
        )
    }
}
function mapStateToProps(state){
    return{initialdetails:state.initialdetails}
}
export default connect()((mapStateToProps)(Map));