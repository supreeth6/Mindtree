import React, { Component } from "react";
import { connect } from "react-redux";
import { delet } from "../actions/action";
import {
	Link,
	Route,
	Router,
	withRouter,
	BrowserRouter
} from "react-router-dom";
import Update from "./Update";

class List extends Component {
	del = dresscode => {
		console.log(dresscode);
		let { dispatch } = this.props;
		dispatch(delet(dresscode));
	};

	render() {
		console.log(this.props.state);
		return (
			<div>
				<table>
					<tr>
						<th>Dresscode</th>
						<th> Brand</th>
						<th>Gender</th>
						<th>Type</th>
						<th>Price</th>
						<th>Stock</th>
					</tr>
					{this.props.state.map((cloth, index) => (
						<tr>
							<td>{cloth.DressCode}</td>
							<td>{cloth.Brand}</td>
							<td>{cloth.Gender}</td>
							<td>{cloth.type}</td>
							<td>{cloth.Price}</td>
							<td>{cloth.Stock}</td>
							<td>
								<button
									onClick={() => {
										this.del(cloth.DressCode);
									}}
								>
									Delete
								</button>
							</td>
							<td>
								<BrowserRouter>
									<Link to="/update">
										<button>Update</button>
									</Link>
									<Route
										path="/update"
										render={props => (
											<Update {...props} isAuthed={true} details={cloth} />
										)}
									/>
								</BrowserRouter>
							</td>
						</tr>
					))}
				</table>
			</div>
		);
	}
}
function mapStateToProps(state) {
	//	console.log("hello", state);
	return { state: state.cloths };
}

export default connect(mapStateToProps)(List);
