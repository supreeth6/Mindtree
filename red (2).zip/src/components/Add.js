import React, { Component } from "react";
import { connect } from "react-redux";
import { add } from "../actions/action";

class Add extends Component {
	constructor() {
		super();
		this.state = {
			details: {
				DressCode: "",
				Brand: "",
				Gender: "",
				Type: "",
				Price: 0,
				Stock: 0
			}
		};
	}
	submit = () => {
		let { dispatch } = this.props;
		dispatch(add(this.state.details));
	};
	onModelChange = event => {
		console.log(event.target.value);
		let name = event.target.name;

		let value = event.target.value;
		this.setState(prevState => ({
			details: {
				...prevState.details,
				[name]: value
			}
		}));
	};
	render() {
		console.log(this.props.state);
		return (
			<div>
				DressCode:{" "}
				<input type="text" onChange={this.onModelChange} name="DressCode" />
				<br></br>
				Brand:
				<input type="text" onChange={this.onModelChange} name="Brand" />
				<br></br>
				Gender: Male
				<input
					onChange={this.onModelChange}
					type="radio"
					name="Gender"
					value="Male"
				/>
				Female
				<input
					onChange={this.onModelChange}
					type="radio"
					name="Gender"
					value="Female"
				/>
				<br></br>
				Type:
				<input onChange={this.onModelChange} type="text" name="Type" />
				<br></br>
				Price:
				<input onChange={this.onModelChange} type="number" name="Price" />
				<br></br>
				Stock:
				<input onChange={this.onModelChange} type="number" name="Stock" />
				<br></br>
				<button onClick={this.submit}>Submit</button>
			</div>
		);
	}
}
function mapStateToProps(state) {
	//	console.log("hello", state);
	return { state: state.cloths };
}

export default connect(mapStateToProps)(Add);
