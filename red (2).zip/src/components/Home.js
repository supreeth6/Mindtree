import React, { Component } from "react";
import { Route } from "react-router-dom";
import Add from "./Add";
import List from "./List";
import Update from "./Update";
import Sample from "./Sample";

export default class Home extends Component {
	render() {
		return (
			<div>
				<Sample />
				<Route exact path="/add" component={Add} />
				<Route exact path="/list" component={List} />
				{/* <Route exact path="/update" component={Update} /> */}
			</div>
		);
	}
}
