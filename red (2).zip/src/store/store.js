import { createStore } from "redux";
import reducer from "../reducers/reducers";

const instialState = { cloths: [] };

const store = createStore(reducer, instialState);
export default store;
