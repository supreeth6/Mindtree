export const add = obj => {
	return {
		type: "ADD",
		detail: obj
	};
};
export const delet = dresscode => {
	return {
		type: "DELETE",
		detail: dresscode
	};
};
export const update = (obj, dresscode) => {
	return {
		type: "UPDATE",
		detail: { newCloth: obj, code: dresscode }
	};
};
