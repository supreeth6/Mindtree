import { reducer, loginReducer, userReducer } from './reducer';
import { combineReducers } from 'redux';

const rootReducer = combineReducers({
  events: reducer,
  users: userReducer,
  //   ///cart: cartReducer,
  userDetails: loginReducer,
});
export default rootReducer;
