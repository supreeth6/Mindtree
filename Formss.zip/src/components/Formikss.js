import React, { Component } from 'react';
import { withFormik, Form, Field } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

class Formi extends Component {
  render() {
    return (
      <div>
        <Form>
          {/* {console.log(this.props.values)} */}
          {this.props.errors.email && (
            <p style={{ color: 'red' }}>{this.props.errors.email}</p>
          )}
          EMAIL:
          <Field type="text" name="email" />
          <br />
          {this.props.errors.password && <p>{this.props.errors.password}</p>}
          PASSWORD:
          <Field type="password" name="password" />
          <br />
          <button /* disabled={this.props.isSubmitting} */ type="submit">
            submit
          </button>
        </Form>
      </div>
    );
  }
}
const Formik = withFormik({
  mapPropsToValues(props) {
    return {
      email: '',
      password: '',
    };
  },
  validationSchema: Yup.object().shape({
    email: Yup.string().email('not valid').required('email is needed'),
    password: Yup.string()
      .required('password is needed')
      .min(8, 'should contain 8')
      .max(32, 'cannot exceed 32'),
  }),
  handleSubmit(values, { setErrors, setSubmitting }) {
    axios
      .post('http://localhost:3000/mindtree/authenticate', values)
      .then((res) => console.log(res))
      .catch((error) => setErrors({ email: error.response.data.message }));
    // console.log(values.email);
  },
});

export default Formik(Formi);
