import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { fetchStates } from "../store/actions";
import { connect } from "react-redux";
import TableCell from "../atom/TableCell";
import Typography from "../atom/Typhography";

import TableContainer from "../organism/TableContainer";

import TableRow from "../molecules/TableRow";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableHead from "@material-ui/core/TableHead";
import Paper from "@material-ui/core/Paper";

class ListOfAllDetails extends Component {
  componentDidMount = () => {
    this.props.dispatch(fetchStates());
  };

  render() {
    console.log(this.props);
    const datas = this.props.affectedstate?.raw_data.filter(
      (value, idx, newdata) =>
        value.detectedstate === this.props.match.params.list
    );
    console.log(datas);

    const uniqueDatas = Array.from(
      new Set(datas.map((item) => item.detecteddistrict))
    );
    const uniqueDatasGender = Array.from(
      new Set(datas.map((item) => item.gender))
    );
    let male = 0;
    let female = 0;
    let unk = 0;
    datas.reduce((acc, item) => {
      return item.gender === "M"
        ? (male = male + 1)
        : item.gender === "F"
        ? (female = female + 1)
        : item.gender === ""
        ? (unk = unk + 1)
        : "";
    }, {});
    console.log(unk, female, male);
    console.log(uniqueDatasGender.length);
    console.log("states", uniqueDatasGender);
    return (
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>
                {" "}
                <Typography variant="h1">District</Typography>
              </TableCell>
              <TableCell>
                <Typography variant="h6">
                  {" "}
                  <Link to={`/showByGender/M/${this.props.match.params.list}`}>
                    <ul>Male {male}</ul>
                  </Link>
                </Typography>
              </TableCell>
              <TableCell>
                {" "}
                <Typography variant="h6">
                  {" "}
                  <Link to={`/showByGender/F/${this.props.match.params.list}`}>
                    <ul>Female {female}</ul>
                  </Link>
                </Typography>
              </TableCell>
              <TableCell>
                {" "}
                <Typography variant="h6">
                  {" "}
                  {/* <Link to={`/showByGender/''/${this.props.match.params.list}`}> */}
                  <ul>Unknown {unk}</ul>
                  {/* </Link> */}
                </Typography>
              </TableCell>

              {/* <TableCell>Female</TableCell>
              <TableCell>male</TableCell>
              <TableCell>Unknown</TableCell> */}
            </TableRow>
          </TableHead>
          <TableBody>
            {this.props.affectedstate.raw_data ? (
              <>
                {uniqueDatas.map((items, idx) => (
                  <TableRow key={idx}>
                    <TableCell>
                      <Link to={"/affectedPeople/" + items}>
                        <paper>{items}</paper>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}

                {/* <Link to={`/showByGender/M/${this.props.match.params.list}`}>
                    <ul>Male {male}</ul>
                  </Link>
                  <Link to={`/showByGender/F/${this.props.match.params.list}`}>
                    <ul> Female {female}</ul>
                  </Link>
                  <Link to={`/showByGender/''/${this.props.match.params.list}`}>
                    <ul> Unknown {unk}</ul>
                  </Link> */}
              </>
            ) : (
              <div>no data</div>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    );
  }
}
function mapStateToProps(state) {
  console.log("dfghjkl", state.states);

  return {
    affectedstate: state.states,
  };
}
export default withRouter(connect(mapStateToProps)(ListOfAllDetails));
