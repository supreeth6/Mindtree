import React, { Component } from "react";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "../atom/TableCell";
import TableContainer from "../organism/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "../molecules/TableRow";
import Paper from "@material-ui/core/Paper";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
class AffectedData extends Component {
  render() {
    console.log("done");
    const filteredData = this.props.affectedstate.raw_data
      .filter(
        (element) => element.detecteddistrict === this.props.match.params.list
      )
      //   .map((item) => item.detecteddistrict)
      .filter((value, index, self) => self.indexOf(value) === index);
    console.log(filteredData);

    return (
      <>
        <TableContainer component={Paper}>
          <Table aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell align="right">Entry ID</TableCell>
                <TableCell align="right">District</TableCell>
                {/* <TableCell align="right">State</TableCell> */}
                <TableCell align="right">Date Announced</TableCell>
                <TableCell align="right">Current Status</TableCell>
                <TableCell align="right">Notes</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredData.map((item, idx) => (
                <TableRow key={idx}>
                  <TableCell align="right">
                    <paper>{item.entryid}</paper>
                  </TableCell>
                  <TableCell align="right">
                    <paper>{item.detecteddistrict}</paper>
                  </TableCell>
                  {/* <TableCell>
                    <paper>{item.detectedstate}</paper>
                  </TableCell> */}
                  <TableCell align="right">
                    <paper> {item.dateannounced}</paper>
                  </TableCell>
                  <TableCell align="right">
                    <paper>{item.currentstatus}</paper>
                  </TableCell>
                  <TableCell align="right">
                    <paper> {item.notes}</paper>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </>
    );
  }
}
function mapStateToProps(state) {
  console.log("dfghjkl", state.states);

  return {
    affectedstate: state.states,
  };
}
export default withRouter(connect(mapStateToProps)(AffectedData));
