import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import { fetchStates } from "../../store/actions";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "../../atom/TableCell";
import TableContainer from "../TableContainer";
import TableRow from "../../molecules/TableRow";
// import TableCell from "@material-ui/core/TableCell";
// import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
// import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

class ListOfStates extends Component {
  componentDidMount() {
    this.props.dispatch(fetchStates());
  }

  render() {
    console.log("states", this.props);
    const listoffilterdata = this.props.affectedstate?.raw_data
      ?.map((item) => item.detectedstate)
      .filter((value, idx, newdata) => newdata.indexOf(value) === idx);
    console.log(listoffilterdata);

    return (
      <>
        <TableContainer component={Paper}>
          <Table style={{ minWidth: 650 }}>
            <TableHead>
              <TableRow>
                <TableCell>Names</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <>
                {this.props.affectedstate.length <= 0 ? (
                  <>no data</>
                ) : (
                  <>
                    {this.props.affectedstate.raw_data ? (
                      <>
                        {this.props.affectedstate.raw_data
                          .map((item) => item.detectedstate)
                          .filter(
                            (value, idx, newdata) =>
                              newdata.indexOf(value) === idx
                          )
                          .map((items, idx) => (
                            <TableRow key={idx}>
                              <TableCell>
                                <Link to={"/listofalldetails/" + items}>
                                  <paper>
                                    {items === ""
                                      ? "This state has no name"
                                      : items}
                                  </paper>
                                </Link>
                              </TableCell>
                            </TableRow>
                          ))}
                      </>
                    ) : (
                      <div>no data</div>
                    )}
                  </>
                )}
              </>
            </TableBody>
          </Table>
        </TableContainer>
      </>
    );
  }
}
function mapStateToProps(state) {
  console.log("dfghjkl", state.states);

  return {
    affectedstate: state.states,
  };
}
export default withRouter(connect(mapStateToProps)(ListOfStates));
