import React from "react";
import { TableContainer } from "@material-ui/core";

export default function index(props) {
  return <TableContainer>{props.children}</TableContainer>;
}
