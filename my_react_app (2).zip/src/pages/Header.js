import React from "react";
import { Link } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
// import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "../atom/Typhography";
import AppBar from "../atom/AppBar";
// import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    justifyContent: "space-around",
    backgroundColor: "black",
    textDecorationColor: "white",
  },

  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    flexGrow: 1,
  },
}));

function Header(props) {
  const classes = useStyles();

  return (
    <div style={{ height: "990px" }}>
      <div className={classes.root}>
        <AppBar position="static">
          <Toolbar className={classes.root}>
            <IconButton
              edge="start"
              className={classes.menuButton}
              color="inherit"
              aria-label="menu"
            >
              LOGO
            </IconButton>
            <Typography
              variant="h6"
              style={{ color: "white" }}
              className={classes.title}
            >
              details
            </Typography>

            <Typography className={classes.root}>
              <Link
                style={{ textDecorationLine: "none", color: "white" }}
                to="/home"
              >
                Home
              </Link>
              <br />
            </Typography>

            <Typography className={classes.root}>
              <Link
                style={{ textDecorationLine: "none", color: "white" }}
                to="/listofstates"
              >
                List All states
              </Link>
              <br />
            </Typography>

            <Typography className={classes.root}>
              {" "}
              <Link
                style={{ textDecorationLine: "none", color: "white" }}
                to="/listofalldetails/:list"
              >
                All
              </Link>
            </Typography>
            <Typography className={classes.root}>
              <Link
                style={{ textDecorationLine: "none", color: "white" }}
                to="/affectedPeople/:list"
              >
                Affected People
              </Link>
              <br />
            </Typography>
          </Toolbar>
        </AppBar>
      </div>
    </div>
  );
}

export default Header;
