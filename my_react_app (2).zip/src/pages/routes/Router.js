import React from "react";
import { Switch, Route } from "react-router-dom";
import ListOfStates from "../../organism/Table/ListOfStates";
import Home from "../../pages/Home";
import Header from "../Header";
import ShowByGender from "../../organism/ShowByGender";
import AffectedData from "../../organism/AffectedData";
import ListOfAllDetails from "../../organism/ListOfAllDetails";

const Router = (props) => {
  return (
    <Switch>
      <Route exact path="/listofstates" component={ListOfStates} />
      <Route exact path="/" component={Header} />
      <Route exact path="/home" component={Home} />
      <Route
        exact
        path="/listofalldetails/:list"
        component={ListOfAllDetails}
      />
      <Route
        exact
        path="/showByGender/:gender/:state"
        component={(props) => <ShowByGender {...props} />}
      />
      <Route
        exact
        path="/affectedPeople/:list"
        component={(props) => <AffectedData {...props} />}
      />
    </Switch>
  );
};
export default Router;
