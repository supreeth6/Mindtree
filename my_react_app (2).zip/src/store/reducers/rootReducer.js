import {
    LIST_OF_STATES_SUCCESS,
    LIST_OF_STATES_REQUEST,
    LIST_OF_STATES_FAILURE

} from "../constants/action-types"
const initialState =  {
    states:[],
    erroe:""
}
const rootReducer =(state = initialState,action)=>{
    switch (action.type){
        case LIST_OF_STATES_SUCCESS :{
            return{

                ...state ,states:action.payload
            };

        }
        case LIST_OF_STATES_REQUEST:{
            return{
                ...state
            }
        }
        case LIST_OF_STATES_FAILURE:{
            return{
                state:[],
                error:""
            }
        }
        default: return state;
        
    }
   
}
export default rootReducer;