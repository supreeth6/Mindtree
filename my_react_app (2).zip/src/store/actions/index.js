import {
    LIST_OF_STATES_SUCCESS,
    LIST_OF_STATES_REQUEST,
    LIST_OF_STATES_FAILURE

} from "../constants/action-types"

import axios from "axios";
export function getListOfStatesSuccess(payload){
    return {type:LIST_OF_STATES_SUCCESS,payload:payload}
}
export function getListOfStatesRequest(){
    return {type:LIST_OF_STATES_REQUEST}
}
export function getListOfStatesFailure(){
    return {type:LIST_OF_STATES_FAILURE}
}
export const fetchStates = ()=>{
    return function(dispatch){
        
        axios.get("https://api.covid19india.org/raw_data3.json")
        .then((response)=>{
            dispatch(getListOfStatesSuccess(response.data));
        }).catch((error)=>{
            dispatch(getListOfStatesFailure());
        })
    }
}