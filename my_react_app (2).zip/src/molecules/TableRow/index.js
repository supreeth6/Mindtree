import React from "react";
import { TableRow } from "@material-ui/core";

export default function index(props) {
  return <TableRow>{props.children}</TableRow>;
}
