import React from "react";
import TableCell from "@material-ui/core/TableCell";
export default function index(props) {
  return <TableCell>{props.children}</TableCell>;
}
